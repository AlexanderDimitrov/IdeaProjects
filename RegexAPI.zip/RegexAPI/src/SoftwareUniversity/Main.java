package SoftwareUniversity;

public class Main {

}
